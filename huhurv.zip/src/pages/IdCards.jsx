// ─────────────────────────────────────────────────────────────
//  src/pages/IdCards.jsx
//  Admin panel — ID Card generator for all employees
//  • Horizontal (CR80 credit-card) & Vertical (portrait) layouts
//  • Logo loaded from Cloudinary (no embedded base64)
//  • Downloads individual or all cards as PDF via jsPDF + html2canvas
// ─────────────────────────────────────────────────────────────
import { useState, useEffect, useRef, useCallback } from "react";
import { useTheme } from "../App";
import { subscribeEmployees } from "../firebase/firestoreService";
import {
  CreditCard, Download, Search, Users,
  ChevronDown, CheckCircle2, X, RectangleHorizontal, RectangleVertical,
  Maximize2, Minimize2,
} from "lucide-react";
import { getOptimizedUrl } from "../cloudinary/cloudinaryService";

// ── Company logo URL from Cloudinary (set via env or hard-code your Cloudinary URL) ──
// Replace this with your actual Cloudinary URL after uploading the logo
const LOGO_URL =
  import.meta.env.VITE_COMPANY_LOGO_URL ||
  "https://res.cloudinary.com/YOUR_CLOUD_NAME/image/upload/v1/ems/company/logo.png";

// Fallback: text initials when logo URL is not set or fails to load
const COMPANY_INITIALS = "RWT";
const COMPANY_NAME     = "Royals Webtech Pvt. Ltd.";
const COMPANY_WEBSITE  = "www.royalswebtechpvtltd.com";
const COMPANY_PHONE    = "+91 8788447944";

// ── Helpers ───────────────────────────────────────────────────
function getInitials(name) {
  if (!name) return "?";
  return name.trim().split(/\s+/).map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

// ── Load jsPDF + html2canvas from CDN ────────────────────────
let _libs = null;
async function loadLibs() {
  if (_libs) return _libs;
  await Promise.all([
    new Promise((res, rej) => {
      if (window.jspdf?.jsPDF) { res(); return; }
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
      s.onload = res; s.onerror = rej;
      document.head.appendChild(s);
    }),
    new Promise((res, rej) => {
      if (window.html2canvas) { res(); return; }
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
      s.onload = res; s.onerror = rej;
      document.head.appendChild(s);
    }),
  ]);
  _libs = { jsPDF: window.jspdf.jsPDF, html2canvas: window.html2canvas };
  return _libs;
}

// ─────────────────────────────────────────────────────────────
//  HORIZONTAL card (CR80: 85.6mm × 54mm)
//  Looks like a real bank / employee card
// ─────────────────────────────────────────────────────────────
function IdCardHorizontal({ emp, cardRef }) {
  const [logoError, setLogoError] = useState(false);

  return (
    <div
      ref={cardRef}
      style={{
        width: "340px", height: "215px",
        borderRadius: "14px",
        background: "linear-gradient(135deg, #0d0d0d 0%, #1c1c1c 55%, #111 100%)",
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 20px 60px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04)",
        fontFamily: "'Arial', sans-serif",
        flexShrink: 0,
      }}
    >
      {/* Top accent bar */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: "4px",
        background: "linear-gradient(90deg, #CC0000 0%, #FF4444 50%, #CC0000 100%)",
      }} />

      {/* Decorative rings */}
      <div style={{ position:"absolute", right:"-40px", top:"-40px", width:"160px", height:"160px",
        borderRadius:"50%", border:"1px solid rgba(204,0,0,0.12)", pointerEvents:"none" }} />
      <div style={{ position:"absolute", right:"-20px", top:"-20px", width:"100px", height:"100px",
        borderRadius:"50%", border:"1px solid rgba(204,0,0,0.08)", pointerEvents:"none" }} />
      <div style={{ position:"absolute", left:"-30px", bottom:"-30px", width:"120px", height:"120px",
        borderRadius:"50%", border:"1px solid rgba(0,200,200,0.06)", pointerEvents:"none" }} />

      {/* Subtle dot grid */}
      <div style={{
        position:"absolute", inset:0, pointerEvents:"none",
        backgroundImage:"radial-gradient(circle, rgba(255,255,255,0.022) 1px, transparent 1px)",
        backgroundSize:"16px 16px",
      }} />

      {/* ── Header: Logo + Company name ── */}
      <div style={{
        position:"absolute", top:"13px", left:"14px", right:"14px",
        display:"flex", alignItems:"center", gap:"9px",
      }}>
        {/* Logo or initials */}
        <div style={{
          width:"32px", height:"32px", borderRadius:"8px",
          background:"rgba(204,0,0,0.15)", border:"1px solid rgba(204,0,0,0.3)",
          display:"flex", alignItems:"center", justifyContent:"center",
          overflow:"hidden", flexShrink:0,
        }}>
          {!logoError && LOGO_URL && !LOGO_URL.includes("YOUR_CLOUD_NAME") ? (
            <img
              src={getOptimizedUrl ? getOptimizedUrl(LOGO_URL) : LOGO_URL}
              alt="logo"
              crossOrigin="anonymous"
              style={{ width:"100%", height:"100%", objectFit:"contain" }}
              onError={() => setLogoError(true)}
            />
          ) : (
            <span style={{ fontSize:"11px", fontWeight:700, color:"#CC0000", letterSpacing:"0.05em" }}>
              {COMPANY_INITIALS}
            </span>
          )}
        </div>

        <div style={{ borderLeft:"1px solid rgba(204,0,0,0.35)", paddingLeft:"9px", flex:1 }}>
          <div style={{ fontSize:"6.5px", color:"#CC0000", fontWeight:700,
            letterSpacing:"0.18em", textTransform:"uppercase" }}>
            EMPLOYEE IDENTITY CARD
          </div>
          <div style={{ fontSize:"6px", color:"#777", letterSpacing:"0.06em", marginTop:"1px" }}>
            {COMPANY_NAME}
          </div>
        </div>
      </div>

      {/* ── Vertical separator ── */}
      <div style={{
        position:"absolute", left:"122px", top:"52px", bottom:"28px", width:"1px",
        background:"linear-gradient(180deg, transparent, rgba(204,0,0,0.35), transparent)",
      }} />

      {/* ── Left: Photo + EMP ID ── */}
      <div style={{
        position:"absolute", left:"14px", top:"52px",
        width:"100px", display:"flex", flexDirection:"column", alignItems:"center", gap:"7px",
      }}>
        {/* Photo */}
        <div style={{
          width:"70px", height:"70px", borderRadius:"50%",
          border:"2.5px solid #CC0000",
          boxShadow:"0 0 0 3px rgba(204,0,0,0.12), 0 4px 16px rgba(0,0,0,0.5)",
          overflow:"hidden", background:"#1a1a1a",
          display:"flex", alignItems:"center", justifyContent:"center",
        }}>
          {emp.photoUrl ? (
            <img src={emp.photoUrl} alt={emp.name} crossOrigin="anonymous"
              style={{ width:"100%", height:"100%", objectFit:"cover" }} />
          ) : (
            <span style={{ fontSize:"24px", fontWeight:700, color:"#CC0000" }}>
              {getInitials(emp.name)}
            </span>
          )}
        </div>

        {/* EMP ID badge */}
        <div style={{
          background:"rgba(204,0,0,0.1)", border:"1px solid rgba(204,0,0,0.3)",
          borderRadius:"4px", padding:"2px 7px", textAlign:"center", width:"100%",
          boxSizing:"border-box",
        }}>
          <div style={{ fontSize:"5px", color:"#CC0000", letterSpacing:"0.12em", fontWeight:700 }}>
            EMP ID
          </div>
          <div style={{ fontSize:"7.5px", color:"#FFF", fontFamily:"'Courier New', monospace",
            fontWeight:700, marginTop:"1px", whiteSpace:"nowrap",
            overflow:"hidden", textOverflow:"ellipsis" }}>
            {emp.id || "—"}
          </div>
        </div>
      </div>

      {/* ── Right: Employee details ── */}
      <div style={{
        position:"absolute", left:"134px", top:"53px", right:"12px",
        display:"flex", flexDirection:"column", gap:"5px",
      }}>
        {/* Name */}
        <div style={{
          fontSize:"13px", fontWeight:700, color:"#FFF",
          lineHeight:1.15, letterSpacing:"0.01em",
          whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis",
        }}>
          {emp.name || "—"}
        </div>

        {/* Role chip */}
        <div style={{
          display:"inline-flex", alignItems:"center",
          background:"rgba(204,0,0,0.14)", border:"1px solid rgba(204,0,0,0.28)",
          borderRadius:"4px", padding:"2px 8px", alignSelf:"flex-start",
        }}>
          <span style={{ fontSize:"7px", color:"#FF6666", fontWeight:600, letterSpacing:"0.06em" }}>
            {emp.role || "Employee"}
          </span>
        </div>

        {/* Info rows */}
        {[
          ["DEPT",  emp.department || "—"],
          ["EMAIL", emp.email || "—"],
          ["PHONE", emp.phone || "—"],
          ["JOIN",  emp.joinDate || "—"],
        ].map(([label, value]) => (
          <div key={label} style={{ display:"flex", gap:"5px", alignItems:"baseline" }}>
            <span style={{ fontSize:"5.5px", color:"#CC0000", fontWeight:700,
              letterSpacing:"0.14em", minWidth:"29px", flexShrink:0 }}>
              {label}
            </span>
            <span style={{ fontSize:"7px", color:"#BBBBBB", lineHeight:1.2,
              whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", maxWidth:"160px" }}>
              {value}
            </span>
          </div>
        ))}
      </div>

      {/* ── Bottom bar ── */}
      <div style={{
        position:"absolute", bottom:0, left:0, right:0, height:"28px",
        background:"linear-gradient(90deg, #CC0000 0%, #990000 100%)",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        padding:"0 14px",
      }}>
        <span style={{ fontSize:"6px", color:"rgba(255,255,255,0.75)", letterSpacing:"0.08em" }}>
          {COMPANY_WEBSITE}
        </span>
        <div style={{ display:"flex", gap:"1.5px", alignItems:"center" }}>
          {[3,5,2,4,3,6,2,4,3,5,2].map((h, i) => (
            <div key={i} style={{ width:"1px", height:`${h}px`, background:"rgba(255,255,255,0.55)" }} />
          ))}
        </div>
        <span style={{ fontSize:"6px", color:"rgba(255,255,255,0.65)", letterSpacing:"0.04em" }}>
          {COMPANY_PHONE}
        </span>
      </div>

      {/* Separator above footer */}
      <div style={{
        position:"absolute", bottom:"28px", left:0, right:0, height:"1px",
        background:"rgba(204,0,0,0.25)",
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  VERTICAL card (portrait: 54mm × 85.6mm)
// ─────────────────────────────────────────────────────────────
function IdCardVertical({ emp, cardRef }) {
  const [logoError, setLogoError] = useState(false);

  return (
    <div
      ref={cardRef}
      style={{
        width: "215px", height: "340px",
        borderRadius: "14px",
        background: "linear-gradient(180deg, #0d0d0d 0%, #1c1c1c 50%, #111 100%)",
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 20px 60px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04)",
        fontFamily: "'Arial', sans-serif",
        flexShrink: 0,
      }}
    >
      {/* Top accent bar */}
      <div style={{
        position:"absolute", top:0, left:0, right:0, height:"4px",
        background:"linear-gradient(90deg, #CC0000, #FF4444, #CC0000)",
      }} />

      {/* Decorative bg rings */}
      <div style={{ position:"absolute", right:"-50px", top:"-50px", width:"180px", height:"180px",
        borderRadius:"50%", border:"1px solid rgba(204,0,0,0.1)", pointerEvents:"none" }} />
      <div style={{ position:"absolute", left:"-30px", bottom:"-30px", width:"130px", height:"130px",
        borderRadius:"50%", border:"1px solid rgba(0,200,200,0.06)", pointerEvents:"none" }} />

      {/* ── Header ── */}
      <div style={{
        position:"absolute", top:"12px", left:0, right:0,
        display:"flex", flexDirection:"column", alignItems:"center", gap:"5px", padding:"0 12px",
      }}>
        {/* Logo / initials */}
        <div style={{
          width:"40px", height:"40px", borderRadius:"10px",
          background:"rgba(204,0,0,0.15)", border:"1px solid rgba(204,0,0,0.3)",
          display:"flex", alignItems:"center", justifyContent:"center",
          overflow:"hidden",
        }}>
          {!logoError && LOGO_URL && !LOGO_URL.includes("YOUR_CLOUD_NAME") ? (
            <img
              src={getOptimizedUrl ? getOptimizedUrl(LOGO_URL) : LOGO_URL}
              alt="logo" crossOrigin="anonymous"
              style={{ width:"100%", height:"100%", objectFit:"contain" }}
              onError={() => setLogoError(true)}
            />
          ) : (
            <span style={{ fontSize:"14px", fontWeight:700, color:"#CC0000" }}>
              {COMPANY_INITIALS}
            </span>
          )}
        </div>
        <div style={{ textAlign:"center" }}>
          <div style={{ fontSize:"7px", color:"#CC0000", fontWeight:700,
            letterSpacing:"0.15em", textTransform:"uppercase" }}>
            EMPLOYEE ID CARD
          </div>
          <div style={{ fontSize:"6px", color:"#666", letterSpacing:"0.05em", marginTop:"2px" }}>
            {COMPANY_NAME}
          </div>
        </div>
      </div>

      {/* ── Horizontal separator ── */}
      <div style={{
        position:"absolute", top:"85px", left:"14px", right:"14px", height:"1px",
        background:"linear-gradient(90deg, transparent, rgba(204,0,0,0.4), transparent)",
      }} />

      {/* ── Photo (centered) ── */}
      <div style={{
        position:"absolute", top:"95px", left:"50%", transform:"translateX(-50%)",
      }}>
        <div style={{
          width:"80px", height:"80px", borderRadius:"50%",
          border:"2.5px solid #CC0000",
          boxShadow:"0 0 0 3px rgba(204,0,0,0.12), 0 4px 20px rgba(0,0,0,0.5)",
          overflow:"hidden", background:"#1a1a1a",
          display:"flex", alignItems:"center", justifyContent:"center",
        }}>
          {emp.photoUrl ? (
            <img src={emp.photoUrl} alt={emp.name} crossOrigin="anonymous"
              style={{ width:"100%", height:"100%", objectFit:"cover" }} />
          ) : (
            <span style={{ fontSize:"28px", fontWeight:700, color:"#CC0000" }}>
              {getInitials(emp.name)}
            </span>
          )}
        </div>
      </div>

      {/* ── Name + Role ── */}
      <div style={{
        position:"absolute", top:"185px", left:"10px", right:"10px",
        textAlign:"center",
      }}>
        <div style={{
          fontSize:"14px", fontWeight:700, color:"#FFF",
          whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis",
        }}>
          {emp.name || "—"}
        </div>

        <div style={{
          display:"inline-flex", alignItems:"center", marginTop:"5px",
          background:"rgba(204,0,0,0.14)", border:"1px solid rgba(204,0,0,0.28)",
          borderRadius:"4px", padding:"2px 9px",
        }}>
          <span style={{ fontSize:"7.5px", color:"#FF6666", fontWeight:600, letterSpacing:"0.05em" }}>
            {emp.role || "Employee"}
          </span>
        </div>
      </div>

      {/* ── Separator ── */}
      <div style={{
        position:"absolute", top:"215px", left:"14px", right:"14px", height:"1px",
        background:"linear-gradient(90deg, transparent, rgba(204,0,0,0.3), transparent)",
      }} />

      {/* ── Info fields ── */}
      <div style={{
        position:"absolute", top:"222px", left:"12px", right:"12px",
        display:"flex", flexDirection:"column", gap:"6px",
      }}>
        {/* EMP ID */}
        <div style={{
          display:"flex", justifyContent:"center",
          background:"rgba(204,0,0,0.1)", border:"1px solid rgba(204,0,0,0.28)",
          borderRadius:"5px", padding:"3px 8px",
        }}>
          <span style={{ fontSize:"6px", color:"#CC0000", fontWeight:700,
            letterSpacing:"0.12em", marginRight:"6px" }}>EMP ID</span>
          <span style={{ fontSize:"8px", color:"#FFF", fontFamily:"'Courier New',monospace",
            fontWeight:700 }}>{emp.id || "—"}</span>
        </div>

        {[
          ["DEPT",  emp.department || "—"],
          ["EMAIL", emp.email || "—"],
          ["PHONE", emp.phone || "—"],
          ["JOIN",  emp.joinDate || "—"],
        ].map(([label, value]) => (
          <div key={label} style={{ display:"flex", gap:"5px", alignItems:"baseline" }}>
            <span style={{ fontSize:"5.5px", color:"#CC0000", fontWeight:700,
              letterSpacing:"0.12em", minWidth:"28px", flexShrink:0 }}>
              {label}
            </span>
            <span style={{ fontSize:"7px", color:"#BBBBBB", lineHeight:1.2,
              whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", maxWidth:"152px" }}>
              {value}
            </span>
          </div>
        ))}
      </div>

      {/* ── Bottom bar ── */}
      <div style={{
        position:"absolute", bottom:0, left:0, right:0, height:"30px",
        background:"linear-gradient(90deg, #CC0000, #990000)",
        display:"flex", alignItems:"center", justifyContent:"center", gap:"12px",
      }}>
        <div style={{ display:"flex", gap:"1.5px", alignItems:"center" }}>
          {[3,5,2,4,3,6,2,4,3].map((h, i) => (
            <div key={i} style={{ width:"1px", height:`${h}px`, background:"rgba(255,255,255,0.55)" }} />
          ))}
        </div>
        <span style={{ fontSize:"6px", color:"rgba(255,255,255,0.75)", letterSpacing:"0.08em" }}>
          {COMPANY_WEBSITE}
        </span>
        <div style={{ display:"flex", gap:"1.5px", alignItems:"center" }}>
          {[3,5,2,4,3,6,2,4,3].map((h, i) => (
            <div key={i} style={{ width:"1px", height:`${h}px`, background:"rgba(255,255,255,0.55)" }} />
          ))}
        </div>
      </div>

      <div style={{
        position:"absolute", bottom:"30px", left:0, right:0, height:"1px",
        background:"rgba(204,0,0,0.25)",
      }} />
    </div>
  );
}

// ── Download helpers ──────────────────────────────────────────
async function downloadCard(cardRef, emp, orientation) {
  const { jsPDF, html2canvas } = await loadLibs();
  const canvas = await html2canvas(cardRef.current, {
    scale: 3, useCORS: true, allowTaint: true,
    backgroundColor: null, logging: false,
  });
  const imgData = canvas.toDataURL("image/png");
  const isH = orientation === "horizontal";
  // CR80: 85.6mm × 54mm
  const W = isH ? 85.6 : 54;
  const H = isH ? 54   : 85.6;
  const doc = new jsPDF({ orientation: isH ? "landscape" : "portrait", unit: "mm", format: [W, H] });
  doc.addImage(imgData, "PNG", 0, 0, W, H);
  const safeName = (emp.name || "Employee").replace(/\s+/g, "_");
  doc.save(`IDCard_${safeName}_${emp.id || "RWT"}.pdf`);
}

async function downloadAllCards(refs, employees, orientation) {
  const { jsPDF, html2canvas } = await loadLibs();
  const isH = orientation === "horizontal";
  const W = isH ? 85.6 : 54;
  const H = isH ? 54   : 85.6;
  const doc = new jsPDF({ orientation: isH ? "landscape" : "portrait", unit: "mm", format: [W, H] });

  for (let i = 0; i < refs.current.length; i++) {
    const ref = refs.current[i];
    if (!ref) continue;
    const canvas = await html2canvas(ref, {
      scale: 3, useCORS: true, allowTaint: true,
      backgroundColor: null, logging: false,
    });
    const imgData = canvas.toDataURL("image/png");
    if (i > 0) doc.addPage([W, H], isH ? "landscape" : "portrait");
    doc.addImage(imgData, "PNG", 0, 0, W, H);
  }
  doc.save("RWT_All_ID_Cards.pdf");
}

// ── Main Page ─────────────────────────────────────────────────
export default function IdCards() {
  const { theme }                       = useTheme();
  const isDark                          = theme === "dark";
  const [employees, setEmployees]       = useState([]);
  const [filtered,  setFiltered]        = useState([]);
  const [search,    setSearch]          = useState("");
  const [loading,   setLoading]         = useState(true);
  const [downloading, setDownloading]   = useState(null);
  const [deptFilter, setDeptFilter]     = useState("All");
  const [success,   setSuccess]         = useState(null);
  // "horizontal" = landscape CR80 | "vertical" = portrait
  const [orientation, setOrientation]   = useState("horizontal");

  const cardRefs = useRef([]);

  // Colour tokens
  const bg     = isDark ? "#0A0A0A" : "#F4F4F4";
  const card   = isDark ? "#111111" : "#FFFFFF";
  const border = isDark ? "#1E1E1E" : "#E0E0E0";
  const text   = isDark ? "#F0F0F0" : "#111111";
  const sub    = isDark ? "#666666" : "#888888";

  useEffect(() => {
    const unsub = subscribeEmployees((emps) => {
      setEmployees(emps);
      setFiltered(emps);
      setLoading(false);
    });
    return unsub;
  }, []);

  useEffect(() => {
    let result = employees;
    if (deptFilter !== "All") result = result.filter(e => e.department === deptFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(e =>
        (e.name  || "").toLowerCase().includes(q) ||
        (e.email || "").toLowerCase().includes(q) ||
        (e.id    || "").toLowerCase().includes(q) ||
        (e.role  || "").toLowerCase().includes(q)
      );
    }
    setFiltered(result);
    cardRefs.current = new Array(result.length).fill(null);
  }, [search, deptFilter, employees]);

  const departments = ["All", ...new Set(employees.map(e => e.department).filter(Boolean))];

  const handleDownload = async (emp, idx) => {
    setDownloading(emp.id);
    try {
      await downloadCard({ current: cardRefs.current[idx] }, emp, orientation);
      setSuccess(emp.id);
      setTimeout(() => setSuccess(null), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(null);
    }
  };

  const handleDownloadAll = async () => {
    setDownloading("all");
    try {
      await downloadAllCards(cardRefs, filtered, orientation);
      setSuccess("all");
      setTimeout(() => setSuccess(null), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(null);
    }
  };

  // Grid column size depends on card orientation
  const gridMinWidth = orientation === "horizontal" ? "380px" : "260px";

  return (
    <div style={{ minHeight: "100vh", background: bg }}>

      {/* ── Page Header ── */}
      <div style={{
        background: card, border: `1px solid ${border}`, borderRadius: "12px",
        padding: "18px 22px", marginBottom: "20px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        flexWrap: "wrap", gap: "12px",
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:"14px" }}>
          <div style={{
            width:"44px", height:"44px", borderRadius:"10px", flexShrink:0,
            background:"rgba(204,0,0,0.1)", border:"1px solid rgba(204,0,0,0.25)",
            display:"flex", alignItems:"center", justifyContent:"center",
          }}>
            <CreditCard size={22} style={{ color:"#CC0000" }} />
          </div>
          <div>
            <h2 style={{ fontFamily:"Rajdhani, sans-serif", fontWeight:700, fontSize:"22px", color:text, margin:0 }}>
              ID Cards
            </h2>
            <p style={{ fontFamily:"Mulish, sans-serif", fontSize:"12px", color:sub, margin:0 }}>
              Generate &amp; download employee ID cards
            </p>
          </div>
        </div>

        <div style={{ display:"flex", gap:"10px", flexWrap:"wrap", alignItems:"center" }}>
          {/* Stats */}
          <div style={{
            background: isDark ? "#0A0A0A" : "#F5F5F5", border:`1px solid ${border}`,
            borderRadius:"8px", padding:"8px 14px",
            display:"flex", alignItems:"center", gap:"8px",
          }}>
            <Users size={14} style={{ color:"#00B8B8" }} />
            <span style={{ fontFamily:"Rajdhani, sans-serif", fontWeight:700, fontSize:"14px", color:text }}>
              {filtered.length}
            </span>
            <span style={{ fontFamily:"Mulish, sans-serif", fontSize:"11px", color:sub }}>cards</span>
          </div>

          {/* Orientation toggle */}
          <div style={{
            display:"flex", alignItems:"center", gap:"0",
            border:`1px solid ${border}`, borderRadius:"8px", overflow:"hidden",
          }}>
            <button
              onClick={() => setOrientation("horizontal")}
              title="Horizontal (landscape) card"
              style={{
                display:"flex", alignItems:"center", gap:"5px",
                padding:"8px 13px", cursor:"pointer", fontSize:"12px",
                fontFamily:"Rajdhani, sans-serif", fontWeight:700, letterSpacing:"0.04em",
                border:"none", transition:"all 150ms",
                background: orientation === "horizontal" ? "#CC0000" : "transparent",
                color: orientation === "horizontal" ? "#FFF" : sub,
              }}
            >
<RectangleHorizontal size={13} />
              HORIZONTAL
            </button>
            <div style={{ width:"1px", background:border, height:"100%", flexShrink:0 }} />
            <button
              onClick={() => setOrientation("vertical")}
              title="Vertical (portrait) card"
              style={{
                display:"flex", alignItems:"center", gap:"5px",
                padding:"8px 13px", cursor:"pointer", fontSize:"12px",
                fontFamily:"Rajdhani, sans-serif", fontWeight:700, letterSpacing:"0.04em",
                border:"none", transition:"all 150ms",
                background: orientation === "vertical" ? "#CC0000" : "transparent",
                color: orientation === "vertical" ? "#FFF" : sub,
              }}
            >
              <RectangleVertical size={13} />
              VERTICAL
            </button>
          </div>

          {/* Download All */}
          <button
            onClick={handleDownloadAll}
            disabled={downloading === "all" || filtered.length === 0}
            style={{
              display:"flex", alignItems:"center", gap:"7px",
              padding:"9px 16px", borderRadius:"8px",
              cursor: filtered.length === 0 ? "not-allowed" : "pointer",
              background: downloading === "all"
                ? "rgba(204,0,0,0.08)"
                : success === "all"
                ? "rgba(0,184,100,0.12)"
                : "#CC0000",
              border: (downloading === "all" || success === "all")
                ? `1px solid ${success === "all" ? "#00B864" : "rgba(204,0,0,0.3)"}`
                : "none",
              color: downloading === "all" ? "#CC0000" : success === "all" ? "#00B864" : "#FFF",
              fontFamily:"Rajdhani, sans-serif", fontWeight:700, fontSize:"13px",
              letterSpacing:"0.06em", transition:"all 200ms",
            }}
          >
            {downloading === "all" ? (
              <><Spinner />&nbsp;GENERATING…</>
            ) : success === "all" ? (
              <><CheckCircle2 size={14} />ALL DOWNLOADED</>
            ) : (
              <><Download size={14} />DOWNLOAD ALL ({filtered.length})</>
            )}
          </button>
        </div>
      </div>

      {/* ── Filters ── */}
      <div style={{
        background: card, border:`1px solid ${border}`, borderRadius:"10px",
        padding:"12px 16px", marginBottom:"20px",
        display:"flex", gap:"12px", flexWrap:"wrap", alignItems:"center",
      }}>
        {/* Search */}
        <div style={{ position:"relative", flex:1, minWidth:"200px" }}>
          <Search size={13} style={{ position:"absolute", left:"12px", top:"50%",
            transform:"translateY(-50%)", color:sub }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, ID, role…"
            style={{
              width:"100%", paddingLeft:"34px", paddingRight:"12px",
              paddingTop:"8px", paddingBottom:"8px",
              borderRadius:"7px", outline:"none", fontSize:"12px",
              background: isDark ? "#0A0A0A" : "#F5F5F5",
              border:`1px solid ${border}`, color:text,
              fontFamily:"Mulish, sans-serif", boxSizing:"border-box",
            }}
            onFocus={e => { e.target.style.border="1px solid #CC0000"; e.target.style.boxShadow="0 0 0 3px rgba(204,0,0,0.08)"; }}
            onBlur={e  => { e.target.style.border=`1px solid ${border}`; e.target.style.boxShadow="none"; }}
          />
          {search && (
            <button onClick={() => setSearch("")} style={{
              position:"absolute", right:"10px", top:"50%", transform:"translateY(-50%)",
              background:"none", border:"none", cursor:"pointer", color:sub, padding:"2px",
            }}>
              <X size={12} />
            </button>
          )}
        </div>

        {/* Dept filter */}
        <div style={{ position:"relative" }}>
          <select
            value={deptFilter}
            onChange={e => setDeptFilter(e.target.value)}
            style={{
              appearance:"none", padding:"8px 28px 8px 12px",
              borderRadius:"7px", outline:"none", fontSize:"12px",
              background: isDark ? "#0A0A0A" : "#F5F5F5",
              border:`1px solid ${border}`, color:text,
              fontFamily:"Mulish, sans-serif", cursor:"pointer",
            }}
          >
            {departments.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <ChevronDown size={12} style={{ position:"absolute", right:"8px", top:"50%",
            transform:"translateY(-50%)", color:sub, pointerEvents:"none" }} />
        </div>
      </div>

      {/* ── Cards Grid ── */}
      {loading ? (
        <div style={{ display:"flex", justifyContent:"center", padding:"60px 0" }}>
          <Spinner size={36} color="#CC0000" />
        </div>
      ) : filtered.length === 0 ? (
        <div style={{
          textAlign:"center", padding:"60px 20px",
          background:card, borderRadius:"12px", border:`1px solid ${border}`,
        }}>
          <CreditCard size={40} style={{ color:sub, marginBottom:"12px" }} />
          <p style={{ fontFamily:"Rajdhani, sans-serif", fontSize:"18px", color:sub }}>
            No employees found
          </p>
        </div>
      ) : (
        <div style={{
          display:"grid",
          gridTemplateColumns: `repeat(auto-fill, minmax(${gridMinWidth}, 1fr))`,
          gap:"20px",
        }}>
          {filtered.map((emp, idx) => (
            <div
              key={emp.id}
              style={{
                background:card, border:`1px solid ${border}`, borderRadius:"14px",
                padding:"18px 18px 14px", display:"flex", flexDirection:"column",
                gap:"14px", transition:"border-color 200ms, box-shadow 200ms",
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = "rgba(204,0,0,0.35)";
                e.currentTarget.style.boxShadow = "0 4px 24px rgba(204,0,0,0.07)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = border;
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              {/* Employee name header */}
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <div>
                  <div style={{ fontFamily:"Rajdhani, sans-serif", fontWeight:700, fontSize:"15px", color:text }}>
                    {emp.name}
                  </div>
                  <div style={{ fontFamily:"'Share Tech Mono', monospace", fontSize:"10px",
                    color:"#00B8B8", marginTop:"1px" }}>
                    {emp.id}
                  </div>
                </div>
                <div style={{
                  padding:"3px 9px", borderRadius:"20px", fontSize:"10px",
                  background:"rgba(204,0,0,0.1)", color:"#CC0000",
                  fontFamily:"Mulish, sans-serif", fontWeight:600,
                  border:"1px solid rgba(204,0,0,0.2)",
                }}>
                  {emp.department || "—"}
                </div>
              </div>

              {/* Card Preview — centered */}
              <div style={{ display:"flex", justifyContent:"center" }}>
                {orientation === "horizontal" ? (
                  <IdCardHorizontal emp={emp} cardRef={el => { cardRefs.current[idx] = el; }} />
                ) : (
                  <IdCardVertical emp={emp} cardRef={el => { cardRefs.current[idx] = el; }} />
                )}
              </div>

              {/* Download button */}
              <button
                onClick={() => handleDownload(emp, idx)}
                disabled={downloading === emp.id}
                style={{
                  width:"100%", padding:"10px", borderRadius:"8px",
                  cursor: downloading === emp.id ? "not-allowed" : "pointer",
                  background: success === emp.id
                    ? "rgba(0,184,100,0.1)"
                    : downloading === emp.id
                    ? "rgba(204,0,0,0.06)"
                    : "rgba(204,0,0,0.08)",
                  border:`1px solid ${success === emp.id ? "rgba(0,184,100,0.3)" : "rgba(204,0,0,0.2)"}`,
                  color: success === emp.id ? "#00B864" : "#CC0000",
                  fontFamily:"Rajdhani, sans-serif", fontWeight:700, fontSize:"12px",
                  letterSpacing:"0.1em",
                  display:"flex", alignItems:"center", justifyContent:"center", gap:"7px",
                  transition:"all 200ms",
                }}
              >
                {downloading === emp.id ? (
                  <><Spinner size={12} color="#CC0000" />&nbsp;GENERATING PDF…</>
                ) : success === emp.id ? (
                  <><CheckCircle2 size={13} />DOWNLOADED</>
                ) : (
                  <><Download size={13} />DOWNLOAD ID CARD</>
                )}
              </button>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

// ── Mini spinner ──────────────────────────────────────────────
function Spinner({ size = 16, color = "#CC0000" }) {
  return (
    <div style={{
      width:`${size}px`, height:`${size}px`, borderRadius:"50%",
      border:`2px solid rgba(204,0,0,0.2)`, borderTopColor:color,
      animation:"spin 0.7s linear infinite", flexShrink:0,
    }} />
  );
}