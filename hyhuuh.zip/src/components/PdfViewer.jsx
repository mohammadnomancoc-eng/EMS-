// src/components/PdfViewer.jsx
//
// Renders a PDF from any public URL inline using pdfjs-dist.
//
// HOW IT WORKS — why this solves the 401:
//   1. fetch() runs from YOUR app's origin (localhost:5173 or royalswebtechems.netlify.app)
//      which IS in your Cloudinary "Allowed fetch domains" whitelist → no 401.
//   2. The bytes are turned into a blob:// URL that lives in your origin.
//   3. PDF.js reads the blob URL (same-origin) and renders each page onto a <canvas>.
//   No external viewer, no mozilla.github.io, no cross-origin iframe.

import { useState, useEffect, useRef } from "react";
import * as pdfjsLib from "pdfjs-dist";

// Point the worker at the copy shipped with pdfjs-dist (Vite serves /node_modules via ?)
// Using a CDN worker that exactly matches the installed version.
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

export default function PdfViewer({ url, theme, border }) {
  const isDark     = theme === "dark";
  const canvasRefs = useRef([]);

  const [pages,    setPages]    = useState(0);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(null);
  const [pdfDoc,   setPdfDoc]   = useState(null);

  // ── Step 1: fetch PDF as blob from YOUR origin ───────────────
  useEffect(() => {
    if (!url) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setPdfDoc(null);
    setPages(0);

    fetch(url, { mode: "cors" })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status} — PDF not accessible`);
        return r.arrayBuffer();
      })
      .then((buffer) => {
        if (cancelled) return;
        return pdfjsLib.getDocument({ data: buffer }).promise;
      })
      .then((pdf) => {
        if (cancelled || !pdf) return;
        setPdfDoc(pdf);
        setPages(pdf.numPages);
        setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err.message || "Failed to load PDF");
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, [url]);

  // ── Step 2: render each page onto its canvas ─────────────────
  useEffect(() => {
    if (!pdfDoc || pages === 0) return;

    for (let i = 1; i <= pages; i++) {
      pdfDoc.getPage(i).then((page) => {
        const canvas = canvasRefs.current[i - 1];
        if (!canvas) return;

        const viewport = page.getViewport({ scale: 1.5 });
        canvas.width  = viewport.width;
        canvas.height = viewport.height;

        page.render({
          canvasContext: canvas.getContext("2d"),
          viewport,
        });
      });
    }
  }, [pdfDoc, pages]);

  // ── UI ────────────────────────────────────────────────────────
  const containerStyle = {
    borderRadius: "10px",
    overflow: "hidden",
    border: `1px solid ${border}`,
    background: isDark ? "#111111" : "#F0F0F0",
    minHeight: "200px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: loading || error ? "center" : "flex-start",
    padding: loading || error ? "32px" : "0",
    gap: "12px",
  };

  if (loading) return (
    <div style={containerStyle}>
      <div style={{
        width: "22px", height: "22px", borderRadius: "50%",
        border: "2px solid #00B8B8", borderTopColor: "transparent",
        animation: "spin 0.8s linear infinite",
      }} />
      <span style={{ fontFamily: "Mulish, sans-serif", fontSize: "12px",
        color: isDark ? "#666666" : "#999999" }}>
        Loading PDF…
      </span>
    </div>
  );

  if (error) return (
    <div style={containerStyle}>
      <span style={{ fontFamily: "Mulish, sans-serif", fontSize: "12px",
        color: "#CC0000", textAlign: "center" }}>
        ⚠ {error}
      </span>
      <a href={url} target="_blank" rel="noopener noreferrer"
        style={{ fontFamily: "Rajdhani, sans-serif", fontWeight: 700, fontSize: "12px",
          color: "#00B8B8", textDecoration: "none", letterSpacing: "0.06em" }}>
        OPEN IN NEW TAB ↗
      </a>
    </div>
  );

  return (
    <div style={containerStyle}>
      {Array.from({ length: pages }, (_, i) => (
        <canvas
          key={i}
          ref={(el) => (canvasRefs.current[i] = el)}
          style={{
            width: "100%",
            display: "block",
            borderBottom: i < pages - 1 ? `1px solid ${border}` : "none",
          }}
        />
      ))}
    </div>
  );
}
