# 🔥 Firebase Backend Integration Guide

This document explains every step to connect the EMSD frontend to a real Firebase backend.

---

## 1. Create a Firebase Project

1. Go to [https://console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → give it a name (e.g. `emsd-royals`)
3. Disable Google Analytics (optional) → **Create project**

---

## 2. Enable Authentication

1. In the Firebase Console → **Build → Authentication → Get started**
2. Choose **Email/Password** → Enable → Save

---

## 3. Enable Firestore

1. **Build → Firestore Database → Create database**
2. Choose **Start in production mode** (our rules handle access)
3. Pick a region close to your users (e.g. `asia-south1` for India)

---

## 4. Register a Web App & Get Config

1. Project Settings (⚙) → **Your apps → Add app → Web (</>)**
2. Register the app (name it anything)
3. Copy the `firebaseConfig` object
4. Paste it into **`src/firebase/config.js`** replacing the placeholder values

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "emsd-royals.firebaseapp.com",
  projectId: "emsd-royals",
  storageBucket: "emsd-royals.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123",
};
```

---

## 5. Create Auth Users

For each team member create an account in **Authentication → Users → Add user**:

| Email                       | Password  | Notes           |
|-----------------------------|-----------|-----------------|
| admin@royals.com            | (strong)  | Admin account   |
| arjun@royalswebtech.com     | (strong)  | Employee RWT001 |
| … (one per employee)        |           |                 |
noman@royalswebtech.com         noman123

---

## 6. Create Firestore User Profile Documents

For each Auth user, create a document in the `users` collection with the **UID** as the document ID:

**Admin example** (`users/{adminUid}`):
```json
{
  "role": "admin",
  "name": "Admin",
  "initials": "AD",
  "empId": null
}
```

**Employee example** (`users/{arjunUid}`):
```json
{
  "role": "employee",
  "name": "Arjun Sharma",
  "initials": "AS",
  "empId": "RWT001"
}
```

---

## 7. Seed the Database (employees, departments, leave requests)

Temporarily add this to any component (e.g. `Dashboard.jsx`) and visit the page once:

```jsx
import { seedDatabase } from "../firebase/seed";
import { useEffect } from "react";

// Inside the component:
useEffect(() => {
  seedDatabase(); // ← remove after seeding!
}, []);
```

Check the Firestore Console to confirm the collections are populated, then remove the seed call.

---

## 8. Deploy Firestore Rules & Indexes

```bash
npm install -g firebase-tools
firebase login
firebase use --add          # select your project
firebase deploy --only firestore
```

---

## 9. (Optional) Deploy to Firebase Hosting

```bash
npm run build
firebase deploy --only hosting
```

Your app will be live at `https://YOUR_PROJECT_ID.web.app`

---

## Firestore Collections Overview

| Collection      | Document ID          | Description                         |
|-----------------|----------------------|-------------------------------------|
| `users`         | Firebase Auth UID    | Role, name, empId per user          |
| `employees`     | `RWT001`, `RWT002`…  | Employee master records             |
| `departments`   | `1`, `2`…            | Department records                  |
| `leaveRequests` | Auto ID              | Leave/WFH requests                  |
| `attendance`    | `{empId}_{date}`     | One record per employee per day     |

---

## Files Added / Modified

| File                               | What changed                                  |
|------------------------------------|-----------------------------------------------|
| `src/firebase/config.js`           | NEW – Firebase app init + exports             |
| `src/firebase/authService.js`      | NEW – login, logout, auth state listener      |
| `src/firebase/firestoreService.js` | NEW – all CRUD operations (employees, leave…) |
| `src/firebase/seed.js`             | NEW – one-time data seed helper               |
| `src/pages/Login.jsx`              | MODIFIED – uses `loginUser()` from Firebase   |
| `src/App.jsx`                      | MODIFIED – syncs auth state to localStorage   |
| `src/pages/Employees.jsx`          | MODIFIED – real-time Firestore CRUD           |
| `src/pages/LeaveManagement.jsx`    | MODIFIED – real-time Firestore CRUD           |
| `firestore.rules`                  | NEW – role-based security rules               |
| `firestore.indexes.json`           | NEW – composite indexes for queries           |
| `firebase.json`                    | NEW – Firebase project config                 |
